<?php
  $page_title = 'Todo List';
  require_once('includes/load.php');
  // Checkin What level user has permission to view this page
   page_require_level(3);
?>



<?php

$sql ="SELECT emailId from tblemail";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
if($query->rowCount() > 0):
foreach($results as $result):
$adminemail=$result->emailId;
endforeach;
endif;
if(isset($_POST['submit']))
{
// getting Post values	
$name=$_POST['name'];
$phoneno=$_POST['phonenumber'];
$email=$_POST['emailaddres'];
$subject=$_POST['subject'];
$message=$_POST['message'];
$uip = $_SERVER ['REMOTE_ADDR'];
$isread=0;
// Insert quaery
$sql="INSERT INTO  tblcontactdata(FullName,PhoneNumber,EmailId,Subject,Message,UserIp,Is_Read) VALUES(:fname,:phone,:email,:subject,:message,:uip,:isread)";
$query = $dbh->prepare($sql);
// Bind parameters
$query->bindParam(':fname',$name,PDO::PARAM_STR);
$query->bindParam(':phone',$phoneno,PDO::PARAM_STR);
$query->bindParam(':email',$email,PDO::PARAM_STR);
$query->bindParam(':subject',$subject,PDO::PARAM_STR);
$query->bindParam(':message',$message,PDO::PARAM_STR);
$query->bindParam(':uip',$uip,PDO::PARAM_STR);
$query->bindParam(':isread',$isread,PDO::PARAM_STR);
$query->execute();
$lastInsertId = $dbh->lastInsertId();
if($lastInsertId)
{
//mail function for sending mail
$to=$email.",".$adminemail; 
$headers .= "MIME-Version: 1.0"."\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1'."\r\n";
$headers .= 'From:Cofi-M Pvt (Ltd.)<cofimpvtltd@gmail.com>'."\r\n";
$ms.="<html></body><div>
<div><b>Name:</b> $name,</div>
<div><b>Phone Number:</b> $phoneno,</div>
<div><b>Email Id:</b> $email,</div>";
$ms.="<div style='padding-top:8px;'><b>Message : </b>$message</div><div></div></body></html>";
mail($to,$subject,$ms,$headers);




echo "<script>alert('Your info submitted successfully.');</script>";
}
else 
{
echo "<script>alert('Something went wrong. Please try again');</script>";
}


}

?>

<?php include_once('layouts/header.php'); ?>

<!DOCTYPE HTML>
<html>
<head>
<title> Contact Form </title>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>

<!--web-fonts-->
<link href='//fonts.googleapis.com/css?family=Josefin+Sans:400,100,300,600,700' rel='stylesheet' type='text/css'>
<!--web-fonts-->
<style>

.login-form input[type="submit"] {
	    background: #00acee;
}

.login-form span {
	    background: #00acee;
}

body{
  font-family: 'Josefin Sans', sans-serif;
  background: #fff;
}


</style>

</head>


<body>
				<div class="main-section">
				<div class="login-form">
					<h2>Contact Us if You Can Supply</h2>
					<p>Feel free to drop us a line and we'll get back to you in 24 hours min!</p>
						<span></span>
					<form name="ContactForm" method="post">

<h4>your name</h4>
<input type="text" name="name" class="user" placeholder="Your Name"  autocomplete="off" required>

<h4>your phone number</h4>
<input type="text" name="phonenumber" class="phone" placeholder="+94 00 0000 000" maxlength="10" required autocomplete="off">

<h4>your email address</h4>
<input type="email" name="emailaddres" class="email" placeholder="Example@mail.com" required autocomplete="off">

<h4>your subject</h4>
<input type="text" name="subject" class="email" placeholder="Subject" autocomplete="off">

<h4>your message</h4>
<textarea class="mess" name="message" placeholder="Your Brands, Quantity & Etc." required></textarea>
<input type="submit" value="Your Message" name="submit">
</form>
				
				</div>
				</div>
			</div>

		<!---main--->
		</div>
</body>
</html>