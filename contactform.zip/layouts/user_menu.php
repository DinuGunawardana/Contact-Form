<ul>
  <li>
    <a href="http://localhost/cofi-m/admin-ims-portal/admin.php">
      <i class="glyphicon glyphicon-home"></i>
      <span>Dashboard</span>
    </a>
  </li>
  <li>
    <a href="http://localhost/cofi-m/todolist/supply-orders.php">
      <i class="glyphicon glyphicon-home"></i>
      <span>Supply Orders</span>
    </a>
  </li>
 
</ul>
